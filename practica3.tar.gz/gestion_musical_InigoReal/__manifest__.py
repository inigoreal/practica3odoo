# -*- coding: utf-8 -*-
{
    'name': 'Gestion musical Inigo Real',
    'description': 'Entrega 4',
    'summary': 'Exercici Discs / Songs / Autors - Part 1',
    'website': 'www.inigoreal.estawebtampocoexiste.com',
    'author': 'Inigo Real',
    'depends': ['base','gestion_musical'],
    'data': [
	'views/gestion_musical_views.xml',
    ],
    'application': True,
}

