# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from odoo import fields, models

# DEFINIMOS LOS OBJETOS "DISCO", "AUTORES", "CANCIONES"

class Author(models.Model):
    _inherit = 'author'
    country = fields.Char("Pais")


class Disc(models.Model):
    _inherit = 'disc'
    genere = fields.Char("Genere")

class Gira(models.Model):
    _name = 'gira'

    name = fields.Char("Nombre de la gira", required=True)
    any = fields.Integer("Any")
    ciutats = fields.Char("Ciutats de la gira")
    author_id = fields.Many2one(comodel_name="author", string="Autor de la gira")
    disc_id = fields.Many2one(comodel_name="disc", string="Disc de promocio")
    towp_song_ids = fields.Many2many(comodel_name='song',
                                        relation='gira_song_rel',
                                        column1='gira_id',
                                        column2='song_id',
					string="ssssssssssss")
