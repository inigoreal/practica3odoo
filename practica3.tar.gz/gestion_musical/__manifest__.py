# -*- coding: utf-8 -*-
{
    'name': 'Gestion musical',
    'description': 'Aplicacion de cosas a hacer',
    'summary': 'Tareas a realizar. Te las recordamos.',
    'website': 'www.inigoreal.estawebtampocoexiste.com',
    'author': 'Inigo Real',
    'depends': ['base'],
    'data': ['views/gestion_musical_views.xml'],
    'application': True,
}

